import 'package:flutter/material.dart';

class AppColors {
  static const Color textPrimary = Color(0xFF29436D);
  static const Color border = Color(0xFFEAEAEA);
  static const Color background = Colors.white;
}
